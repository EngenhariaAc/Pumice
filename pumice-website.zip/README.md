# Pumice Website

A simple static website themed around pumice stone.

## Features
- Clean layout
- Gallery section
- Responsive basics

## How to Use
1. Download the zip
2. Extract
3. Open index.html in your browser

## Author
Mortification Records
